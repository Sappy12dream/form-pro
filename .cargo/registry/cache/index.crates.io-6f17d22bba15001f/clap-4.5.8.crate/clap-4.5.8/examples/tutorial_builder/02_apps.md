```console
$ 02_apps --help
Does awesome things

Usage: 02_apps[EXE] --two <VALUE> --one <VALUE>

Options:
      --two <VALUE>  
      --one <VALUE>  
  -h, --help         Print help
  -V, --version      Print version

$ 02_apps --version
MyApp 1.0

```
