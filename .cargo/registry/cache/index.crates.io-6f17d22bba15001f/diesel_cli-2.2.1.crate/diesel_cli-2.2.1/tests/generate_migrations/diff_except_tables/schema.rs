diesel::table! {
    table_a (id) {
        id -> Integer,
        script -> Text,
    }
}
