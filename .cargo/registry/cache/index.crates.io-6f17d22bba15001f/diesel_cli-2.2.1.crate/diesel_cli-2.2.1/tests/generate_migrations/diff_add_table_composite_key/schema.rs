table! {
    users(id, other_key) {
        id -> Integer,
        other_key -> Integer,
        name -> Text,
    }
}
