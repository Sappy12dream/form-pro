table! {
    users {
        id -> BigInt,
        name -> Text,
    }
}
