table! {
    users {
        id -> Integer,
    }
}
