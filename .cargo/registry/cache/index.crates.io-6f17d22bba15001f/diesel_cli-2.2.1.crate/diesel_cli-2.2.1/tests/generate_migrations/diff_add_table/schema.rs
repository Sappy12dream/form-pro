table! {
    users {
        id -> Integer,
        name -> Text,
    }
}
