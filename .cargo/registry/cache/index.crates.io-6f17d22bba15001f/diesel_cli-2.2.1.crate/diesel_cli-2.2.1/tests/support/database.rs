// This file only exists so rustfmt can find it. The path to this module is always overridden by a
// cfg attr
